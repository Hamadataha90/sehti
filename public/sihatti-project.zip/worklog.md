---
Task ID: 2
Agent: Main Orchestrator
Task: Rebrand + implement all feature enhancements for صِحتي

Work Log:
- Generated professional logo (emerald green Arabic letter ص styled into heart+pulse), white version, and favicon using z-ai image generation
- Renamed "Calc Hub" → "صِحتي" across all files: layout.tsx metadata, Header, Footer, HomePage, email templates, AdminPanel
- Added next-themes Dark Mode toggle button in Header with sun/moon icons
- Added search bar in Header (desktop toggle + mobile always visible) that filters articles on HomePage
- Added social sharing buttons on ArticlePage: WhatsApp, X/Twitter, Facebook, copy link
- Added related articles section at bottom of each article (3 articles, image+title cards)
- Added breadcrumb navigation on ArticlePage (الرئيسية / مقال)
- Added Water Calculator (drops visualization, tips, lead capture)
- Added Ideal Weight Calculator (Devine formula, min/max/ideal range)
- Added Daily Calorie Tracker (localStorage persistence, bar chart + line trend chart via recharts, 7-day history)
- Created About page with mission, tools list, disclaimer
- Created Privacy Policy page (6 sections: data collection, usage, protection, cookies, rights, contact)
- Added Newsletter subscription system (Footer form + /api/newsletter API + welcome email)
- Added article category filter (الكل، تغذية، لياقة، صحة عامة، حاسبات) on HomePage
- Added PWA support (manifest.json in public/, viewport meta, theme-color)
- Updated CalculatorsPage to 5 tabs (السعرات, BMI, الماء, الوزن, المتتبع)
- Updated HomePage to show 4 calculator preview cards
- Updated Zustand store with new views (about, privacy), searchQuery, selectedCategory
- Updated page.tsx to handle all new views + pass allArticles to ArticlePage
- Updated email template branding from Calc Hub to صِحتي
- All ESLint checks passing with 0 errors

Stage Summary:
- Brand renamed to "صِحتي" with professional AI-generated logo
- Dark mode, search, social sharing, breadcrumbs, related articles all implemented
- 4 calculators + daily tracker with charts
- Newsletter subscription + About + Privacy pages
- Category filtering on articles
- PWA manifest added
- 0 lint errors, app compiling and running
