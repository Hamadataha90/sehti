'use client';

import { useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import { toast } from 'sonner';

export function Footer() {
  const { navigate, goHome } = useAppStore();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = async () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast.error('يرجى إدخال بريد إلكتروني صالح');
      return;
    }
    setLoading(true);
    try {
      await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      setSubscribed(true);
      toast.success('تم الاشتراك بنجاح! شكرًا لك 🎉');
    } catch {
      toast.error('حدث خطأ أثناء الاشتراك');
    } finally {
      setLoading(false);
    }
  };

  return (
    <footer className="mt-auto border-t border-border/60 bg-muted/30">
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <button onClick={goHome} className="flex items-center gap-2.5 mb-3">
              <Image src="/logo.png" alt="صِحتي" width={32} height={32} className="rounded-lg" />
              <span className="text-lg font-bold text-foreground">صِحتي</span>
            </button>
            <p className="text-sm text-muted-foreground leading-6 mb-4">
              منصة عربية متخصصة في الصحة واللياقة والتغذية. نقدم لك أدوات ومقالات موثوقة لتحسين صحتك.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-3">روابط سريعة</h3>
            <ul className="space-y-2">
              <li><button onClick={goHome} className="text-sm text-muted-foreground hover:text-emerald-600 transition-colors">الرئيسية</button></li>
              <li><button onClick={() => navigate('calculators')} className="text-sm text-muted-foreground hover:text-emerald-600 transition-colors">الحاسبات</button></li>
              <li><button onClick={() => navigate('about')} className="text-sm text-muted-foreground hover:text-emerald-600 transition-colors">من نحن</button></li>
              <li><button onClick={() => navigate('privacy')} className="text-sm text-muted-foreground hover:text-emerald-600 transition-colors">سياسة الخصوصية</button></li>
            </ul>
          </div>

          {/* Tools */}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-3">أدواتنا</h3>
            <ul className="space-y-2">
              <li><button onClick={() => navigate('calculators')} className="text-sm text-muted-foreground hover:text-emerald-600 transition-colors">🔥 حاسبة السعرات</button></li>
              <li><button onClick={() => navigate('calculators')} className="text-sm text-muted-foreground hover:text-emerald-600 transition-colors">📊 حاسبة BMI</button></li>
              <li><button onClick={() => navigate('calculators')} className="text-sm text-muted-foreground hover:text-emerald-600 transition-colors">💧 حاسبة الماء</button></li>
              <li><button onClick={() => navigate('calculators')} className="text-sm text-muted-foreground hover:text-emerald-600 transition-colors">⚖️ الوزن المثالي</button></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-3">📧 النشرة البريدية</h3>
            <p className="text-sm text-muted-foreground mb-3">اشترك ليصلك جديد المقالات والنصائح الصحية</p>
            {!subscribed ? (
              <div className="flex gap-2">
                <Input
                  type="email"
                  placeholder="بريدك الإلكتروني"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="text-sm h-9"
                  dir="ltr"
                />
                <Button onClick={handleSubscribe} disabled={loading} size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white shrink-0 h-9">
                  {loading ? '⏳' : 'اشترك'}
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-sm text-emerald-600 font-medium">
                ✅ تم الاشتراك!
              </div>
            )}
          </div>
        </div>

        <div className="mt-8 border-t border-border/40 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} صِحتي — جميع الحقوق محفوظة. المحتوى لأغراض تثقيفية فقط ولا يُغني عن استشارة الطبيب.
          </p>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            صُنع بـ 💚 لصحتك
          </div>
        </div>
      </div>
    </footer>
  );
}
