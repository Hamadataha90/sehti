'use client';

import { useAppStore } from '@/store/useAppStore';
import { Button } from '@/components/ui/button';

export function PrivacyPage() {
  const { goHome } = useAppStore();

  return (
    <div className="page-transition mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
        <button onClick={goHome} className="hover:text-emerald-600 transition-colors">الرئيسية</button>
        <span className="text-border">/</span>
        <span className="text-foreground font-medium">سياسة الخصوصية</span>
      </nav>

      <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-2">📜 سياسة الخصوصية</h1>
      <p className="text-muted-foreground mb-8">آخر تحديث: {new Date().toLocaleDateString('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' })}</p>

      <div className="prose-arabic space-y-6">
        <section className="rounded-2xl border border-border/60 bg-card p-6 sm:p-8">
          <h2 className="text-lg font-bold text-foreground mb-3">1. المعلومات التي نجمعها</h2>
          <ul className="list-disc list-inside space-y-2 text-muted-foreground text-sm leading-7">
            <li><strong className="text-foreground">عند استخدام الحاسبات:</strong> لا نخزن أي بيانات شخصية. الحسابات تتم في متصفحك فقط.</li>
            <li><strong className="text-foreground">عند الاشتراك بالنشرة البريدية:</strong> نجمع عنوان بريدك الإلكتروني فقط.</li>
            <li><strong className="text-foreground">عند طلب خطة غذائية:</strong> نجمع بريدك الإلكتروني ونتائج الحاسبة التي اخترت مشاركتها.</li>
          </ul>
        </section>

        <section className="rounded-2xl border border-border/60 bg-card p-6 sm:p-8">
          <h2 className="text-lg font-bold text-foreground mb-3">2. كيف نستخدم معلوماتك</h2>
          <ul className="list-disc list-inside space-y-2 text-muted-foreground text-sm leading-7">
            <li>إرسال نتائج الحاسبات عبر البريد الإلكتروني عند طلبك</li>
            <li>إرسال النشرة البريدية إذا اشتركت</li>
            <li>تحسين محتوى الموقع بناءً على تفاعل المستخدمين</li>
          </ul>
        </section>

        <section className="rounded-2xl border border-border/60 bg-card p-6 sm:p-8">
          <h2 className="text-lg font-bold text-foreground mb-3">3. حماية بياناتك</h2>
          <p className="text-muted-foreground text-sm leading-7">
            نلتزم بأعلى معايير حماية البيانات. لا نبيع أو نشارك معلوماتك الشخصية مع أي طرف ثالث. يتم تخزين البيانات بشكل آمن باستخدام تقنيات التشفير الحديثة.
          </p>
        </section>

        <section className="rounded-2xl border border-border/60 bg-card p-6 sm:p-8">
          <h2 className="text-lg font-bold text-foreground mb-3">4. ملفات تعريف الارتباط (Cookies)</h2>
          <p className="text-muted-foreground text-sm leading-7">
            نستخدم ملفات تعريف الارتباط الضرورية فقط لتشغيل الموقع بشكل صحيح. يمكنك التحكم في إعدادات ملفات تعريف الارتباط من خلال إعدادات المتصفح.
          </p>
        </section>

        <section className="rounded-2xl border border-border/60 bg-card p-6 sm:p-8">
          <h2 className="text-lg font-bold text-foreground mb-3">5. حقوقك</h2>
          <ul className="list-disc list-inside space-y-2 text-muted-foreground text-sm leading-7">
            <li>حق الوصول إلى بياناتك الشخصية</li>
            <li>حق طلب حذف بياناتك</li>
            <li>حق إلغاء الاشتراك في النشرة البريدية في أي وقت</li>
          </ul>
        </section>

        <section className="rounded-2xl border border-border/60 bg-card p-6 sm:p-8">
          <h2 className="text-lg font-bold text-foreground mb-3">6. تواصل معنا</h2>
          <p className="text-muted-foreground text-sm leading-7">
            لأي استفسارات حول سياسة الخصوصية، يمكنك التواصل معنا عبر البريد الإلكتروني.
          </p>
        </section>
      </div>

      <div className="text-center pt-6">
        <Button onClick={goHome} variant="outline" className="gap-2">→ العودة للرئيسية</Button>
      </div>
    </div>
  );
}
