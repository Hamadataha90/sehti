'use client';

import { useState, useEffect, useMemo } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { ArticleCard } from './ArticleComponents';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import Image from 'next/image';

interface Article {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string | null;
  coverImage: string;
  calculatorType: string | null;
  createdAt: string;
}

const categories = [
  { id: 'all', label: 'الكل', icon: '📋' },
  { id: 'nutrition', label: 'تغذية', icon: '🥗' },
  { id: 'fitness', label: 'لياقة', icon: '💪' },
  { id: 'health', label: 'صحة عامة', icon: '🏥' },
  { id: 'calculator', label: 'حاسبات', icon: '🧮' },
];

function getArticleCategory(article: Article): string {
  if (article.calculatorType) return 'calculator';
  const title = article.title;
  if (title.includes('تغذية') || title.includes('أطعمة') || title.includes('وزن') || title.includes('حمية')) return 'nutrition';
  if (title.includes('رياضة') || title.includes('عضلات') || title.includes('تمرين')) return 'fitness';
  return 'health';
}

export function HomePage() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const { openArticle, navigate, searchQuery, selectedCategory, setSelectedCategory } = useAppStore();

  useEffect(() => {
    async function fetchArticles() {
      try {
        const response = await fetch('/api/articles');
        const data = await response.json();
        setArticles(data.articles ?? []);
      } catch {
        // silent
      } finally {
        setLoading(false);
      }
    }
    fetchArticles();
  }, []);

  const filteredArticles = useMemo(() => {
    let filtered = articles;
    if (selectedCategory !== 'all') {
      filtered = filtered.filter((a) => getArticleCategory(a) === selectedCategory);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      filtered = filtered.filter((a) =>
        a.title.toLowerCase().includes(q) || (a.excerpt?.toLowerCase().includes(q))
      );
    }
    return filtered;
  }, [articles, selectedCategory, searchQuery]);

  return (
    <div className="page-transition">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-bl from-emerald-50 via-background to-teal-50/30 py-12 sm:py-20">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-20 -left-20 h-60 w-60 rounded-full bg-emerald-100/50 blur-3xl" />
          <div className="absolute -bottom-20 -right-20 h-80 w-80 rounded-full bg-teal-100/40 blur-3xl" />
        </div>
        <div className="relative mx-auto max-w-6xl px-4 sm:px-6">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 rounded-full bg-emerald-100 px-4 py-1.5 text-sm text-emerald-700 font-medium mb-6">
              🌿 صحتك هي أولويتنا
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-foreground leading-tight mb-5">
              حاسباتك الصحية
              <span className="text-emerald-600 block sm:inline"> الذكية</span>
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground leading-relaxed mb-8 max-w-2xl mx-auto">
              أدوات مجانية لحساب السعرات ومؤشر كتلة الجسم والماء، مع مقالات عربية موثوقة في التغذية واللياقة والصحة
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button onClick={() => navigate('calculators')} size="lg" className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold h-12 px-8 text-base">
                🧮 جرّب الحاسبات مجانًا
              </Button>
              <Button variant="outline" size="lg" onClick={() => document.getElementById('articles-section')?.scrollIntoView({ behavior: 'smooth' })} className="h-12 px-8 text-base">
                📖 تصفح المقالات
              </Button>
            </div>
          </div>
          <div className="mt-12 grid grid-cols-3 gap-4 max-w-md mx-auto">
            <div className="text-center"><div className="text-2xl sm:text-3xl font-bold text-emerald-600">4</div><div className="text-xs sm:text-sm text-muted-foreground">حاسبات صحية</div></div>
            <div className="text-center"><div className="text-2xl sm:text-3xl font-bold text-emerald-600">6+</div><div className="text-xs sm:text-sm text-muted-foreground">مقال متخصص</div></div>
            <div className="text-center"><div className="text-2xl sm:text-3xl font-bold text-emerald-600">100%</div><div className="text-xs sm:text-sm text-muted-foreground">مجاني</div></div>
          </div>
        </div>
      </section>

      {/* Calculator Cards */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 py-12">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: '🔥', title: 'حاسبة السعرات', desc: 'احسب احتياجك اليومي من السعرات باستخدام معادلة Mifflin-St Jeor', cls: 'from-emerald-50 to-white' },
            { icon: '📊', title: 'حاسبة BMI', desc: 'تعرف على مؤشر كتلة جسمك وهل وزنك مناسب لطولك', cls: 'from-teal-50 to-white' },
            { icon: '💧', title: 'حاسبة الماء', desc: 'احسب كمية الماء التي يحتاجها جسمك يوميًا', cls: 'from-cyan-50 to-white' },
            { icon: '⚖️', title: 'الوزن المثالي', desc: 'اكتشف الوزن المثالي لطولك وجنسك وعمرك', cls: 'from-amber-50 to-white' },
          ].map((calc) => (
            <button key={calc.title} onClick={() => navigate('calculators')} className={`group rounded-2xl border border-emerald-200 bg-gradient-to-bl ${calc.cls} p-5 sm:p-6 text-right transition-all hover:shadow-lg hover:border-emerald-300 hover:-translate-y-0.5`}>
              <div className="text-3xl sm:text-4xl mb-3">{calc.icon}</div>
              <h2 className="text-base sm:text-lg font-bold text-foreground mb-1.5 group-hover:text-emerald-700 transition-colors">{calc.title}</h2>
              <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">{calc.desc}</p>
              <div className="mt-3 text-emerald-600 font-medium text-xs sm:text-sm inline-flex items-center gap-1 group-hover:gap-2 transition-all">ابدأ الآن ←</div>
            </button>
          ))}
        </div>
      </section>

      {/* Articles Section */}
      <section id="articles-section" className="mx-auto max-w-6xl px-4 sm:px-6 pb-16">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-foreground">📋 أحدث المقالات</h2>
            <p className="text-muted-foreground mt-1 text-sm">{searchQuery ? `نتائج البحث عن "${searchQuery}"` : 'مقالات متخصصة في الصحة والتغذية واللياقة'}</p>
          </div>
        </div>

        {/* Category Filter */}
        <div className="flex gap-2 overflow-x-auto pb-4 mb-6 scrollbar-hide">
          {categories.map((cat) => (
            <Button
              key={cat.id}
              variant={selectedCategory === cat.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(cat.id)}
              className={`shrink-0 ${selectedCategory === cat.id ? 'bg-emerald-600 text-white hover:bg-emerald-700' : ''}`}
            >
              <span className="ml-1">{cat.icon}</span>
              {cat.label}
            </Button>
          ))}
        </div>

        {loading ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="rounded-xl border border-border/60 overflow-hidden">
                <Skeleton className="aspect-[16/10]" />
                <div className="p-5 space-y-3"><Skeleton className="h-5 w-3/4" /><Skeleton className="h-4 w-full" /><Skeleton className="h-4 w-1/2" /></div>
              </div>
            ))}
          </div>
        ) : filteredArticles.length === 0 ? (
          <div className="text-center py-16 rounded-2xl border border-dashed border-border">
            <div className="text-5xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold text-foreground mb-2">
              {searchQuery ? 'لا توجد نتائج للبحث' : 'لا توجد مقالات في هذا التصنيف'}
            </h3>
            <p className="text-muted-foreground mb-4">جرب كلمة بحث أخرى أو تصفح التصنيفات الأخرى</p>
            {searchQuery && <Button variant="outline" onClick={() => useAppStore.getState().setSearchQuery('')}>مسح البحث</Button>}
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredArticles.map((article) => (
              <ArticleCard key={article.id} article={article} onClick={() => openArticle(article)} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
