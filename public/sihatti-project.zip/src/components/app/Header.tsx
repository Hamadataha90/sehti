'use client';

import { useAppStore } from '@/store/useAppStore';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import { useTheme } from 'next-themes';
import Image from 'next/image';

export function Header() {
  const { currentView, navigate, goHome, searchQuery, setSearchQuery } = useAppStore();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const { theme, setTheme } = useTheme();

  const navItems = [
    { id: 'home' as const, label: 'الرئيسية', icon: '🏠' },
    { id: 'calculators' as const, label: 'الحاسبات', icon: '🧮' },
    { id: 'about' as const, label: 'من نحن', icon: '💡' },
  ];

  const handleNav = (view: 'home' | 'calculators' | 'about') => {
    navigate(view);
    setMobileOpen(false);
    setSearchOpen(false);
    if (view === 'home') goHome();
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate('home');
      setMobileOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
        {/* Logo */}
        <button onClick={goHome} className="flex items-center gap-2.5 transition-opacity hover:opacity-80">
          <Image src="/logo.png" alt="صِحتي" width={36} height={36} className="rounded-lg" />
          <span className="text-xl font-bold text-foreground">صِحتي</span>
        </button>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <Button
              key={item.id}
              variant={currentView === item.id ? 'default' : 'ghost'}
              size="sm"
              onClick={() => handleNav(item.id)}
              className={
                currentView === item.id
                  ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                  : 'text-muted-foreground hover:text-foreground'
              }
            >
              <span className="ml-1.5">{item.icon}</span>
              {item.label}
            </Button>
          ))}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-1.5">
          {/* Search Toggle (Desktop) */}
          {searchOpen ? (
            <form onSubmit={handleSearch} className="hidden sm:flex items-center">
              <Input
                type="search"
                placeholder="ابحث في المقالات..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-52 h-9 text-sm"
                autoFocus
              />
            </form>
          ) : (
            <Button variant="ghost" size="icon" onClick={() => setSearchOpen(true)} className="hidden sm:flex text-muted-foreground">
              <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </Button>
          )}

          {/* Dark Mode Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="text-muted-foreground"
          >
            {theme === 'dark' ? (
              <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
            ) : (
              <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>
            )}
          </Button>

          {/* Admin (hidden on mobile) */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('admin-login')}
            className="text-muted-foreground hover:text-foreground hidden lg:flex"
          >
            ⚙️
          </Button>

          {/* Mobile Menu */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 pt-12">
              {/* Mobile Search */}
              <form onSubmit={handleSearch} className="mb-4 px-2">
                <Input
                  type="search"
                  placeholder="ابحث في المقالات..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="text-sm"
                />
              </form>

              <nav className="flex flex-col gap-1">
                {navItems.map((item) => (
                  <Button
                    key={item.id}
                    variant={currentView === item.id ? 'default' : 'ghost'}
                    className={`justify-start ${currentView === item.id ? 'bg-emerald-600 text-white' : 'text-muted-foreground'}`}
                    onClick={() => handleNav(item.id)}
                  >
                    <span className="ml-2">{item.icon}</span>
                    {item.label}
                  </Button>
                ))}
                <div className="my-2 border-t border-border" />
                <Button variant="ghost" className="justify-start text-muted-foreground" onClick={() => { navigate('privacy'); setMobileOpen(false); }}>
                  <span className="ml-2">📜</span>سياسة الخصوصية
                </Button>
                <Button variant="ghost" className="justify-start text-muted-foreground" onClick={() => { navigate('admin-login'); setMobileOpen(false); }}>
                  <span className="ml-2">⚙️</span>لوحة التحكم
                </Button>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
